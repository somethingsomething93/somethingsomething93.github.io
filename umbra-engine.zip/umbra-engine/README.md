# UMBRA ENGINE

A browser-native hub for games, media, and tools.

## Deploy

Drop the folder on any static host — GitHub Pages, Netlify, Cloudflare Pages.

For GitHub Pages: push to a repo, go to **Settings → Pages**, set source to `main` branch root. Done.

## Structure

```
index.html        — entry point, all pages live here
css/main.css      — all styles
js/canvas.js      — loader canvas + mouse-reactive bg geometry
js/app.js         — nav, data, embed logic
```

## Add a card

Open `js/app.js` and add an object to the relevant array:

```js
{ name: "Title", tag: "Category", desc: "Short description.", url: "https://..." }
```

No IDs, no extra markup needed. The renderer handles the rest.
